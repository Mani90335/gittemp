# ECS Golden Image (GAMI) Check — Ali Cloud

This package is the Ali Cloud equivalent of the AWS `ec2GamiCheck.py` rule, restructured to run
on the same CSAO framework your `oss_public_access.py` example uses (`utils.py`,
`EventHandler.py`, `logUtils.py`, `config.py`).

## What's in this zip

```
ali_ecs_gami_check/
├── ecsGamiCheck.py            <- the rule itself (new — written for this task)
├── src/
│   ├── utils/
│   │   ├── utils.py           <- copied verbatim from your oss_public_access.py bundle
│   │   ├── EventHandler.py    <- copied verbatim from your oss_public_access.py bundle
│   │   └── logUtils.py        <- copied verbatim from your oss_public_access.py bundle
│   └── config/
│       └── config.py          <- STUB — see "What you need to fill in" below
└── README.md
```

**Provenance matters here, so to be explicit:**
- `utils.py`, `EventHandler.py`, and `logUtils.py` are reproduced exactly as they appeared in
  the `oss_public_access.py` file you uploaded (that file was a concatenation of multiple
  source files). I split them back into their own files so this package is importable/runnable
  the way your real project is laid out. I did not modify their logic.
- `ecsGamiCheck.py` is new code, written to plug into `EventHandlerECS` (already defined in
  `EventHandler.py`) the same way `ossPublicAccess` plugs into `EventHandlerOSS`.
- `config.py` is **not** your real config file — it was never shared with me. It's a stub that
  documents every constant the other files reference, with placeholder values, so the package
  at least imports cleanly. See below for what to replace.

## How ecsGamiCheck.py works

1. `parseEvent(event, context)` — decodes the ActionTrail/log-store event via
   `utils.fetchLogFromLogStore`, pulls `accountId`, `acsRegion`, and the violating user, then
   resolves the ECS instance(s) involved either from `customEventResource` (single, e.g. a
   manually-triggered compliance check) or `referencedResources['ACS::ECS::Instance']`
   (one or more instances tied to the triggering event).
2. `validateEvent(...)` — instantiates `ecsGamiCheck` (which extends `EventHandlerECS`) and
   calls `.handleEvent()`. `EventHandlerECS.__init__` already handles getting an STS-assumed
   client, fetching instance tags, and resolving the applicable rule configuration/exceptions
   from Table Store + the rule-config OSS bucket — none of that had to be rewritten.
3. `isRuleViolated()` — looks up the instance's Image via `DescribeInstances` /
   `DescribeImages` (old-style `aliyunsdkecs` request objects + `do_action_with_exception`,
   matching how `EventHandlerECS.getTags()` already calls the API), then checks:
   - **Owner check**: is `ImageOwnerAlias` in the approved list
     (`self.applicableRuleConfiguration['approvedImageOwners']` — key name is a guess, see below)
   - **Name-format check**: does the Image name match `config.gamiRegexMarriott`
   - A DSPM carve-out (region `cn-hangzhou`, a specific prod account) mirrors the AWS script's
     CloudTrail lookup, using ActionTrail's `LookupEvents` API instead.
4. `remediate()` / `rollback()` — `StopInstance` / `StartInstance` via the same old-style SDK
   pattern.

## What you need to fill in before this runs

1. **`src/config/config.py`** — replace every `REPLACE_WITH_...` placeholder with your real
   values (RAM role name, rule-config OSS bucket, Table Store endpoint/instance/table names,
   SLS log project/logstore, location data, etc). If you already have a real `config.py` used
   by your other rules, just use that one instead of this stub — I only wrote this because I
   don't have your original.
2. **`approvedImageOwners` key** in `ecsGamiCheck.isRuleViolated()` — I don't know what your
   rule-configuration JSON actually calls the approved-owner list (the OSS example's equivalent
   key is `bucketPolicyAnonymousAccount`). Rename `self.applicableRuleConfiguration.get('approvedImageOwners', [])`
   to whatever key your `RuleConfigurations/ecsGamiCheck.json` will actually use.
3. **Image ownership lookup** — Ali Cloud's `DescribeImages` doesn't return a clean owner
   account ID the way AWS `DescribeImages` returns `OwnerId`; it returns `ImageOwnerAlias`
   (`self` / `system` / `others` / `marketplace`). If you need to check against a specific
   *account ID* (e.g. a shared-services account), you'll likely need to query with
   `ImageOwnerAlias=others` and `ImageOwnerId=<account>` instead, or resolve it against
   whatever Image inventory your team already maintains. I flagged this in the code with a
   comment rather than guessing at a design.
4. **ActionTrail `LookupEvents` import** (`aliyunsdkactiontrail.request.v20171204.LookupEventsRequest`)
   — this isn't shown anywhere in the files you gave me, so I sourced it from Alibaba's public
   SDK docs. If your codebase already has an `EventHandlerActionTrail`-based helper for this
   kind of lookup, use that instead of the inline call I wrote.
5. **`gamiRegexMarriott`** in the stub `config.py` — I put in a plausible regex
   (`^GAMI[_-].+$`) matching the AWS script's description of the naming rule. Confirm it
   matches your actual approved format.

## Not included

Anything that wasn't shown to me — SLB/VPC/RAM tag-fetch SDK modules referenced in
`EventHandler.py` (`SLB_SDK`, `VPC_SDK` — these look like internal wrapper packages, not public
PyPI SDKs), your Master Switch / rule-configuration JSON schemas, and your deployment/packaging
setup (Function Compute trigger config, requirements.txt, etc.) are all outside what I have
visibility into.
