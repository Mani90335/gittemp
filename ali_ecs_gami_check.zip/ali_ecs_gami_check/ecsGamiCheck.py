'''
As a security professional, I want to ensure that ECS instances are launched from an approved,
golden (GAMI) Image, so that only Images meeting Marriott's naming/ownership standards are used.

Conditions for a violation-
.   Non-approved Image: the rule is violated when the Image is not owned by one of the approved
    Marriott/shared-services Ali Cloud accounts
.   Tag/name-format violation: the rule is violated when the Image name does not comply with the
    Marriott GAMI naming format i.e., starts with "GAMI", followed by either an underscore or a
    hyphen, followed by at least one character
'''
import os
import json
from aliyunsdkcore.acs_exception.exceptions import ClientException
from aliyunsdkcore.acs_exception.exceptions import ServerException

# custom imports
from src.utils import logUtils
from src.utils import utils
from src.utils import EventHandler
from src.config import config

MODULE_NAME = __file__


def parseEvent(event, context):
    '''
    This function extracts the relevant information from the log/event and sends the information to
    validateEvent function
    '''

    logUtils.logInfo(MODULE_NAME, 'Inside ' + parseEvent.__name__)

    try:
        event = utils.fetchLogFromLogStore(event, context)
        accountId = event['userIdentity']['accountId']
        region = event['acsRegion']
        ruleName = os.environ['ruleName']

        if 'userName' in event['userIdentity']:
            violatorUserName = event['userIdentity']['userName']
        else:
            violatorUserName = 'Not Available'

        additionalInfo = {}
        additionalInfo['eventName'] = event['eventName']

        if 'customEventResource' in event:
            instanceIds = [event['customEventResource']]
        else:
            instanceIds = event['referencedResources']['ACS::ECS::Instance']

        for instance in instanceIds:
            validateEvent(ruleName, accountId, region, instance, event, additionalInfo, violatorUserName, context)

    except Exception as e:
        logUtils.logError(MODULE_NAME, 'Error captured while trying to parse event...')
        logUtils.logError(MODULE_NAME, e)


def validateEvent(ruleName, accountId, region, resource, eventLog, additionalInfo, violatorId, context):
    '''
    This function initialises the base Event Handler class with fields extracted from the log/event and
    triggers the following actions-
        1. Fetch applicable rule configuration for log based on account/region/configured exceptions etc
        2. Check whether the current state of resource violates the rule or not
        3. Trigger remediation and/or send alerts (only if the rule is violated)
    '''

    try:
        handler = ecsGamiCheck(ruleName, accountId, region, resource, eventLog, additionalInfo, violatorId, context)
        return handler.handleEvent()

    except Exception as e:
        logUtils.logError(MODULE_NAME, e)


class ecsGamiCheck(EventHandler.EventHandlerECS):

    def isRuleViolated(self):
        '''
        Checks whether the ECS instance was launched from an approved, correctly-named golden Image.

        Returns:
            True: the Image is not from an approved account, or its name fails the Marriott GAMI format
            False: the Image passes both checks
        '''
        from aliyunsdkecs.request.v20140526.DescribeInstancesRequest import DescribeInstancesRequest
        from aliyunsdkecs.request.v20140526.DescribeImagesRequest import DescribeImagesRequest

        logUtils.logInfo(MODULE_NAME, 'Inside ' + self.isRuleViolated.__name__)

        self.violationCategory = None
        self.violationDetail = None
        self.imageOwnerAccount = None
        self.imageName = None

        try:
            # look up the Image ID the instance was launched from
            instanceRequest = DescribeInstancesRequest()
            instanceRequest.set_accept_format('json')
            instanceRequest.set_InstanceIds(json.dumps([self.resource]))
            instanceResponse = json.loads(self.client.do_action_with_exception(instanceRequest))
            imageId = instanceResponse['Instances']['Instance'][0]['ImageId']

            # look up the Image itself
            # NOTE: unlike AWS DescribeImages (which returns a clean OwnerId), Ali Cloud's
            # DescribeImages response only gives back ImageOwnerAlias ('self'/'system'/'others'/
            # 'marketplace'). Cross-account ownership (i.e. "is this from our shared services
            # account?") has to be resolved by querying with ImageOwnerAlias='others' and
            # ImageOwnerId=<shared account id>, or by another mechanism your account/Image
            # inventory already tracks. Adjust the lookup below once that piece is confirmed.
            imageRequest = DescribeImagesRequest()
            imageRequest.set_accept_format('json')
            imageRequest.set_ImageId(imageId)
            imageRequest.set_RegionId(self.region)
            imageResponse = json.loads(self.client.do_action_with_exception(imageRequest))
            image = imageResponse['Images']['Image'][0]

            imageOwnerAccount = image.get('ImageOwnerAlias')
            imageName = image.get('ImageName')

            self.imageOwnerAccount = imageOwnerAccount
            self.imageName = imageName

            # Exception for instances created by DSPM (specific to cn-hangzhou / prod account)
            if self.region == 'cn-hangzhou' and self.accountId == '798268158912':
                from aliyunsdkactiontrail.request.v20171204 import LookupEventsRequest

                atRequest = LookupEventsRequest.LookupEventsRequest()
                atRequest.set_accept_format('json')
                atRequest.set_EventName('RunInstances')
                atClient = utils.getClient(self.context, self.accountId, self.region)
                atResponse = json.loads(atClient.do_action_with_exception(atRequest))

                events = sorted(atResponse.get('Events', []), key=lambda e: e['eventTime'])
                if not events:
                    logUtils.logInfo(MODULE_NAME, 'No RunInstances event found for DSPM.')
                else:
                    atEvent = json.loads(events[0]['event'])
                    assumedRoleArn = (atEvent.get('userIdentity') or {}).get('arn', '')
                    if assumedRoleArn in self.applicableRuleConfiguration.get('roleArn', []):
                        logUtils.logInfo(MODULE_NAME, 'The instance is created by DSPM. Exiting....')
                        return False

            # ---------- Non-Approved Owner Category ----------
            approvedImageOwners = self.applicableRuleConfiguration.get('approvedImageOwners', [])
            if imageOwnerAccount not in approvedImageOwners:
                logUtils.logInfo(MODULE_NAME, 'Image is not from an approved account. The ECS instance will be stopped.')
                self.violationCategory = 'NON_APPROVED_OWNER'
                self.violationDetail = f'Image owned by {imageOwnerAccount} is not in the approved Marriott Ali Cloud accounts.'
                return True

            # ---------- Tag/Name Format Violation Category ----------
            import re
            regexMarriott = config.gamiRegexMarriott
            failedFields = {}
            for field, pattern in regexMarriott.items():
                value = imageName if field == 'Name' else image.get(field)
                if value is None or re.match(pattern, value) is None:
                    failedFields[field] = value

            if failedFields:
                logUtils.logInfo(MODULE_NAME, 'The following field(s) failed the Marriott GAMI naming format:')
                logUtils.logInfo(MODULE_NAME, failedFields)
                self.violationCategory = 'TAG_FORMAT_VIOLATION'
                self.violationDetail = f'Image name failed Marriott GAMI format: {failedFields}'
                return True

            logUtils.logInfo(MODULE_NAME, 'Image is from an approved account and its name matches the Marriott GAMI format.')
            return False

        except (ClientException, ServerException) as e:
            logUtils.logInfo(MODULE_NAME, 'Error captured while checking for rule violation...')
            logUtils.logError(MODULE_NAME, e)
            return False

        except Exception as e:
            logUtils.logInfo(MODULE_NAME, 'Error captured while checking for rule violation...')
            logUtils.logError(MODULE_NAME, e)
            return False

    def remediate(self):
        '''
        Stops the ECS instance when it was launched from an Image that isn't approved.
        '''
        from aliyunsdkecs.request.v20140526.StopInstanceRequest import StopInstanceRequest

        logUtils.logInfo(MODULE_NAME, 'Inside ' + self.remediate.__name__)

        try:
            stopRequest = StopInstanceRequest()
            stopRequest.set_accept_format('json')
            stopRequest.set_InstanceId(self.resource)
            self.client.do_action_with_exception(stopRequest)

            logUtils.logInfo(MODULE_NAME, 'Remediation performed successfully, instance stopped.')
            return True

        except Exception as e:
            logUtils.logInfo(MODULE_NAME, 'Error captured while trying to remediate...')
            logUtils.logError(MODULE_NAME, e)

        return False

    def rollback(self):
        '''
        Rolls back the remediation by starting the instance back up.
        Not wired into handleEvent() by the base framework shown in EventHandler.py -
        call this directly if/when your rollback trigger path calls it.
        '''
        from aliyunsdkecs.request.v20140526.StartInstanceRequest import StartInstanceRequest

        logUtils.logInfo(MODULE_NAME, 'Inside ' + self.rollback.__name__)

        try:
            startRequest = StartInstanceRequest()
            startRequest.set_accept_format('json')
            startRequest.set_InstanceId(self.resource)
            self.client.do_action_with_exception(startRequest)

            logUtils.logInfo(MODULE_NAME, 'Remediation rolled back successfully, instance started.')
            return True

        except Exception as e:
            logUtils.logError(MODULE_NAME, 'Unable to rollback remediation: ' + str(e))
            return False

    def getEventCustomPayload(self):
        try:
            payload = {
                'imageName': self.imageName,
                'imageOwnerAccount': self.imageOwnerAccount,
                'violationCategory': self.violationCategory,
                'violationDetail': self.violationDetail,
            }
            return payload
        except Exception as e:
            logUtils.logError(MODULE_NAME, e)
            return None
