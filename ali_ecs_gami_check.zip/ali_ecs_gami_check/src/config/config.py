"""
config.py — STUB / TEMPLATE

Your real config.py was not part of what was shared with me, so this file is a placeholder
listing every constant that src/utils/utils.py, src/utils/EventHandler.py and ecsGamiCheck.py
reference. Replace the placeholder values below with your actual project configuration
(most likely already defined in the config.py you use for your other CSAO Ali Cloud rules,
e.g. the one oss_public_access.py imports from).

Do not deploy this stub as-is.
"""

# --- RAM role assumed in each member account to run checks/remediations ---
# Used by: utils.getClient(), EventHandlerOSS.getClient()
ASSUME_ROLE = "REPLACE_WITH_YOUR_CSAO_ASSUME_ROLE_NAME"  # e.g. "csao-remediation-role"

# --- OSS bucket that stores per-rule configuration/alert-data JSON files ---
# Used by: utils.getFileOSS() (via getRuleConfigurations / getRuleAlertData)
# Expected layout in the bucket:
#   RuleConfigurations/<ruleName>.json
#   RuleAlertData/<ruleName>.json
RULE_CONFIG_BUCKET = "REPLACE_WITH_YOUR_RULE_CONFIG_BUCKET_NAME"

# --- Table Store (OTS) settings used for the Master Switch and time-based exceptions ---
# Used by: utils.getAccountRuleMapping(), utils.recordTimeBasedException()
CSAO_TABLE_STORE = {
    "endpoint": "REPLACE_WITH_YOUR_OTS_ENDPOINT",           # e.g. "https://<instance>.<region>.ots.aliyuncs.com"
    "instanceName": "REPLACE_WITH_YOUR_OTS_INSTANCE_NAME",
    "masterSwitchTable": "REPLACE_WITH_YOUR_MASTER_SWITCH_TABLE_NAME",
    "timeExceptionTable": "REPLACE_WITH_YOUR_TIME_EXCEPTION_TABLE_NAME",
}

# --- Region -> {latitude, longitude, region label} lookup, used for alert enrichment ---
# Used by: utils.getLocationData()
LOCATION_DATA = {
    "cn": {"latitude": "31.23", "longitude": "121.47", "region": "China"},
    # add every region/region-group your accounts run in
}

# --- Number of automatic retry attempts remediate() gets before giving up ---
# Used by: EventHandler.__init__ (self.retryAttempts)
RETRY_ATTEMPTS = 3

# --- Text appended to the alert subject line when an exception (not a hard violation) fires ---
# Used by: CsaoEventHandlerAlibaba.createViolationEvent()
EXCEPTION_ALERT = " (Exception Applied)"

# --- Region passed to the LogClient used to ship remediation/audit logs ---
# Used by: CsaoEventHandlerAlibaba.createViolationEvent()
LOG_STORE_REGION = "REPLACE_WITH_YOUR_LOG_STORE_ENDPOINT_OR_REGION"

# --- Log Service (SLS) project/logstore that remediation/audit events get written to ---
# Used by: CsaoEventHandlerAlibaba.createViolationEvent()
REMEDIATION_LOGS = {
    "projectName": "REPLACE_WITH_YOUR_SLS_PROJECT_NAME",
    "logStoreName": "REPLACE_WITH_YOUR_SLS_LOGSTORE_NAME",
}

# --- GAMI naming-format regexes, keyed by the Image field they validate ---
# Used by: ecsGamiCheck.isRuleViolated()
# Example requirement: Image name starts with "GAMI", then "_" or "-", then at least one more char
gamiRegexMarriott = {
    "Name": r"^GAMI[_-].+$",
}
