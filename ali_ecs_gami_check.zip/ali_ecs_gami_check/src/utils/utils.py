import json
import oss2
from aliyunsdkcore.client import AcsClient
from aliyun.log import LogClient, LogItem
from aliyunsdksts.request.v20150401.AssumeRoleRequest import AssumeRoleRequest
from aliyunsdkcore.auth.credentials import StsTokenCredential
from aliyunsdkcore.acs_exception.exceptions import ClientException
from aliyunsdkcore.acs_exception.exceptions import ServerException
from tablestore import *

# custom imports
from src.config import config
from src.utils import logUtils

MODULE_NAME = __file__

def getClient(context, account, region):
    try:
        roleName = config.ASSUME_ROLE

        creds = StsTokenCredential(context.credentials.accessKeyId, context.credentials.accessKeySecret, context.credentials.securityToken)
        client = AcsClient(credential = creds, region_id = context.region)

        request = AssumeRoleRequest()
        request.set_accept_format('json')
        request.set_RoleArn(f"acs:ram::{account}:role/{roleName}")
        request.set_RoleSessionName("csao")

        response = client.do_action_with_exception(request)

        response = json.loads(response.decode('utf-8'))

        accessKeyId = response['Credentials']['AccessKeyId']
        accessKeySecret = response['Credentials']['AccessKeySecret']
        securityToken = response['Credentials']['SecurityToken']

        stsTokenCredential = StsTokenCredential(accessKeyId, accessKeySecret, securityToken)
        client = AcsClient(credential = stsTokenCredential , region_id = region)

        return client

    except Exception as e:
        logUtils.logInfo(MODULE_NAME, 'Error while creating client...')
        logUtils.logError(MODULE_NAME, e)

def getRuleConfigurations(context, ruleName, accountId):
    try:
        return getFileOSS(context, ruleName, accountId,'RuleConfigurations')

    except Exception as e:
        logUtils.logInfo(MODULE_NAME, 'Error while trying to fetch rule configuration...')
        logUtils.logError(MODULE_NAME, e)
        # DR capability to be be built

def getRuleAlertData(context, ruleName, accountId):
    try:
        return getFileOSS(context, ruleName, accountId,'RuleAlertData')

    except Exception as e:
        logUtils.logInfo(MODULE_NAME, 'Error while trying to fetch rule alert data...')
        logUtils.logError(MODULE_NAME, e)
        # DR capability to be be built

def getFileOSS(context, ruleName, accountId, folderName):

    try:
        bucketName = config.RULE_CONFIG_BUCKET
        auth = oss2.StsAuth(context.credentials.accessKeyId, context.credentials.accessKeySecret, context.credentials.securityToken)

        endpoint = 'oss-cn-shanghai-internal.aliyuncs.com'

        # Initialize a bucket based on the StsAuth instance.
        bucket = oss2.Bucket(auth, endpoint, bucketName)

        key =  f'{folderName}/{ruleName}.json'
        select_json_params = {'Json_Type': 'DOCUMENT'}
        result = bucket.select_object(key, "select * from ossobject", None, select_json_params)
        ruleConfig = json.loads(result.read())

        return ruleConfig

    except Exception as e:
        logUtils.logInfo(MODULE_NAME, 'Error while trying to fetch ' + folderName)
        logUtils.logError(MODULE_NAME, e)

def getLocationData(region):
    try:
        allLocationData = config.LOCATION_DATA

        if region.split('-')[0] == 'cn':
            region = 'cn'

        if region in allLocationData:
            return allLocationData[region]

        else :
            logUtils.logError(MODULE_NAME, "Unknown Region")
            return {
                "latitude": "0.00",
                "longitude": "0.00",
                "region": "Unknown",
            }

    except Exception as e:
        logUtils.logError(MODULE_NAME, e)

def getAccountRuleMapping(context, accountId, ruleName, region):

    creds = context.credentials
    logUtils.logDebug(MODULE_NAME,"Getting Rule Id from Master Switch...")

    try:
        ots_client = OTSClient(config.CSAO_TABLE_STORE['endpoint'],  creds.access_key_id, creds.access_key_secret, config.CSAO_TABLE_STORE['instanceName'], sts_token = creds.security_token)

        primary_key = [('accountId',accountId), ('region',region)]
        consumed, return_row, next_token = ots_client.get_row(config.CSAO_TABLE_STORE['masterSwitchTable'], primary_key)

        if return_row == None:
            primary_key = [('accountId',accountId), ('region','default')]
            consumed, return_row, next_token = ots_client.get_row(config.CSAO_TABLE_STORE['masterSwitchTable'], primary_key)

        for data in return_row.attribute_columns:
            if data[0] == ruleName:
                if data[1] == 'none':
                    logUtils.logInfo(MODULE_NAME, "This rule is disabled in Master Switch...")
                    logUtils.logInfo(MODULE_NAME, "Exiting...")
                    return None

                elif data[1] == 'default':
                    logUtils.logInfo(MODULE_NAME, ruleName)
                    return ruleName

                else:
                    logUtils.logInfo(MODULE_NAME, data[1])
                    return data[1]

        logUtils.logInfo(MODULE_NAME, "No mapping for current rule in Master Switch...")
        logUtils.logInfo(MODULE_NAME, "Exiting...")
        return None

    except Exception as e:
        logUtils.logError(MODULE_NAME, "Error captured while trying to fetch mapping of account in the Master Switch ")
        logUtils.logInfo(MODULE_NAME, "Exiting...")
        logUtils.logError(MODULE_NAME, e)

    return None

# Function to capture any resources falling under the Time-based exceptions
def recordTimeBasedException(resource, ruleName, accountId, region, startTime, endTime, context):

    #retry = 10
    retry = 1

    while(retry>=0):
        try:
            retry = retry - 1
            ots_client = OTSClient(config.CSAO_TABLE_STORE['endpoint'],  context.credentials.accessKeyId, context.credentials.accessKeySecret, config.CSAO_TABLE_STORE['instanceName'], sts_token = context.credentials.securityToken)

            primary_key = [
                ('ruleName', ruleName),
                ('accountId', accountId),
                ('region', region),
                ('resource', resource)
            ]

            attribute_columns = [
                ('startTime',startTime),
                ('endTime', endTime)
            ]
            row = Row(primary_key, attribute_columns)

            ots_client.put_row(config.CSAO_TABLE_STORE['timeExceptionTable'], row)

            logUtils.logInfo(MODULE_NAME,'Time-based exception recorded successfully...')

        except Exception as e:
            logUtils.logError(MODULE_NAME, e)
            logUtils.logInfo(MODULE_NAME, 'Failed, Time-based exception not recorded ...')
            # TO DO DR CAPABILITY

def fetchLogFromLogStore(event, context):
    try:
        event = json.loads(event.decode('utf-8'))

        creds = StsTokenCredential(context.credentials.accessKeyId, context.credentials.accessKeySecret, context.credentials.securityToken)
        client = AcsClient(credential = creds, region_id = context.region)

        if client == None :
            logger.info("Acs client create failed")
            return False

        endpoint = event['source']['endpoint']
        project = event['source']['projectName']
        logstore = event['source']['logstoreName']
        start_cursor = event['source']['beginCursor']
        end_cursor = event['source']['endCursor']
        shard_id = event['source']['shardId']

        loggroup_count = 1

        logClient = LogClient(endpoint, context.credentials.accessKeyId, context.credentials.accessKeySecret, context.credentials.securityToken, context.region)
        res = logClient.pull_logs(project, logstore, shard_id, start_cursor, loggroup_count, end_cursor)
        log_data =  res.get_loggroup_json_list()
        log_data = log_data[0]

        item = LogItem()
        log = json.loads(log_data['logs'][0]['raw_log'])
        return log

    except Exception as e:
        logUtils.logError(MODULE_NAME, "Error while trying to extract log event from trigger event")
        logUtils.logError(MODULE_NAME, e)
