import json
import os
import sys
from datetime import datetime
from src.utils import utils
from src.utils import logUtils
from src.config import config
from aliyun.log import LogClient, LogItem, PutLogsRequest
from aliyunsdkram.request.v20150501.GetAccountAliasRequest import GetAccountAliasRequest

MODULE_NAME = __file__

class EventHandler:

    def __init__(self, ruleName, accountId, region, violatorId, service, resource, eventLog,  additionalInfo, context, client = None):
        self.ruleName = ruleName
        self.accountId = accountId
        self.region = region
        self.violatorId = violatorId
        self.service = service
        self.resource = resource

        self.eventLog = eventLog
        self.additionalInfo = additionalInfo
        self.context = context

        if client is None:
            self.client = self.getClient()
        else:
            self.client = client

        self.tags = self.getTags()
        self.accountRuleConfiguration = self.getAccountRuleConfigurations()
        self.applicableRuleConfiguration = self.getApplicableRuleConfiguration()
        self.accountRuleAlertData = self.getRuleAlertData()
        self.retryAttempts = config.RETRY_ATTEMPTS


    def handleEvent(self):
        try:
            if self.accountRuleConfiguration == None:
                logUtils.logInfo(MODULE_NAME, "No rule configuration configured in the master switch, EIXTING...")
                return

            logUtils.logInfo(MODULE_NAME, "Handling event...")

            if self.isRuleViolated():
                logUtils.logInfo(MODULE_NAME, "***Rule violated***")
                self.handleViolation()

        except Exception as e:
            logUtils.logInfo(MODULE_NAME, f"Caught an unexpected error: ")
            logUtils.logError(MODULE_NAME, e)

    # parse and determine appropriate rule config
    def getApplicableRuleConfiguration(self):
        """
           Fetches the best matching rule configuration based on rule IDs
           Priority Order: E004 > E003 > E002 > E001 > E000

           E004 - Identifies a time-based exception for resource names
           E003 - Identifies a time-based exception for resource tagss
           E002 - Identifies a resource name exception
           E001 - Identifies a resource tags exception
           E000 - Identifies a default rule configuration
        """
        if self.accountRuleConfiguration:
            logUtils.logInfo(MODULE_NAME, "Inside " + self.getApplicableRuleConfiguration.__name__)
            try:
                ruleConfigs = self.accountRuleConfiguration['RuleConfigs']
                matchingConfig = {}
                for items in ruleConfigs:

                    if 'startTime' and 'endTime' in items:
                        startTime = datetime.strptime(items['startTime'], '%m-%d-%Y %H:%M:%S')
                        endTime = datetime.strptime(items['endTime'], '%m-%d-%Y %H:%M:%S')
                        if not(datetime.now()>=startTime and datetime.now() < endTime):
                            continue

                    if 'resources' in items:
                        if self.resource not in items['resources']:
                            continue

                    if 'tags' in items:
                        if self.tags:
                            flag = 0
                            # Iterate over tags in DB
                            for itemtags in items['tags']:

                            # If itemtags is present in resource tagss, break out
                                if itemtags in self.tags:
                                    flag = 1
                                    break

                            if flag == 0:
                                continue
                        else:
                            continue

                # Check if metchingConfig is empty
                    if not bool(matchingConfig) == True:
                        matchingConfig = items

                # Update the matching configuration if a higher priority rule configuration matches the resource
                    elif int((items['ruleConfig']['ExceptionId'])[-3:])> int((matchingConfig['ruleConfig']['ExceptionId'])[-3:]):
                        matchingConfig = items

                # If the final matching exception is time-based, record it in the database
                if matchingConfig['ruleConfig']['ExceptionId'] == 'E003' or matchingConfig['ruleConfig']['ExceptionId'] == 'E004':
                    logUtils.logInfo(MODULE_NAME, 'Recording time exception...')
                    utils.recordTimeBasedException(self.resource, self.ruleName, self.accountId, self.region, matchingConfig['startTime'], matchingConfig['endTime'], self.context)

                elif matchingConfig['ruleConfig']['ExceptionId'] == 'E001':
                    logUtils.logInfo(MODULE_NAME, 'Tag Based exception...')

                print(matchingConfig['ruleConfig'])
                return matchingConfig['ruleConfig']

            except Exception as e:
                logUtils.logError(MODULE_NAME, e)

    def getClient(self):
        raise NotImplementedError

    def getAccountRuleConfigurations(self):
        raise NotImplementedError

    def getRuleAlertData(self):
        raise NotImplementedError

    def isRuleViolated(self):
        raise NotImplementedError

    def handleViolation(self):
        raise NotImplementedError

    def remediate(self):
        raise NotImplementedError

    def createViolationEvent(self, eventInfo):
        raise NotImplementedError

    def getEventPayload(self):
        raise NotImplementedError

    def getTags(self):
        raise NotImplementedError

class CsaoEventHandlerAlibaba(EventHandler):

    def getTags(self):
        return None

    def getClient(self):
        try:
            logUtils.logDebug(MODULE_NAME, "Getting client...")
            return utils.getClient(self.context, self.accountId, self.region)

        except Exception as e:
            logUtils.logError(MODULE_NAME, e)

    def getAccountRuleConfigurations(self):
        try:
            # Get rule ID configured for this rule from the master switch (based on account ID and region)
            accountRuleId = utils.getAccountRuleMapping(self.context, self.accountId, self.ruleName, self.region)
            if accountRuleId:
                logUtils.logDebug(MODULE_NAME,"Getting Rule Id: " +  accountRuleId)
                return utils.getRuleConfigurations(self.context, accountRuleId, self.accountId)
            else:
                return None

        except Exception as e:
            logUtils.logError(MODULE_NAME, e)


    def getRuleAlertData(self):
        try:
            if self.accountRuleConfiguration:
                logUtils.logDebug(MODULE_NAME,"Getting Rule Alert Data...")
                return utils.getRuleAlertData(self.context, self.ruleName, self.accountId)

        except Exception as e:
            logUtils.logError(MODULE_NAME, e)

    # handles the violation, including remediation.
    def handleViolation(self):
        try:

            print(self.applicableRuleConfiguration)
            remediationEnabled = self.applicableRuleConfiguration['remediationsEnabled']
            logUtils.logInfo(MODULE_NAME,"Remediation Enabled: ")
            logUtils.logInfo(MODULE_NAME,remediationEnabled)
            alertsEnabled = self.applicableRuleConfiguration['alertsEnabled']
            logUtils.logInfo(MODULE_NAME,"Alerts Enabled: ")
            logUtils.logInfo(MODULE_NAME,alertsEnabled)
            #remediate event if needed
            if remediationEnabled:
                logUtils.logInfo(MODULE_NAME, 'Initialiting remediation...')
                self.remediate()

            if alertsEnabled:
                logUtils.logInfo(MODULE_NAME, 'Initiating alert to be sent...')
                self.createViolationEvent(remediationEnabled, alertsEnabled)

        except Exception as e:
            logUtils.logError(MODULE_NAME, e)

    def getEventCustomPayload(self):
        return None

    def createViolationEvent(self, remediationEnabled, alertsEnabled):
        try:

            logUtils.logDebug(MODULE_NAME,"Creating violation event...")

            alertData = self.accountRuleAlertData

            event = {}
            event['ruleName'] = self.ruleName
            event['ruleDescription'] = alertData['description']

            if remediationEnabled:
                    event['alertType'] = 'REMEDIATION ALERT'
                    event['subject'] = alertData['remediationAlert']
            else:
                if self.applicableRuleConfiguration['ExceptionId'] == 'E000':
                    event['alertType'] = 'AUDIT ALERT'
                    event['subject'] = alertData['notifyAlert']
                else:
                    event['alertType'] = 'EXCEPTION ALERT'
                    event['subject'] = alertData['notifyAlert'] + config.EXCEPTION_ALERT

            event['resourceType'] = alertData['resourceType']
            event['account'] = self.accountId
            event['violatorId'] = self.violatorId
            event['resource'] = self.resource
            event['region'] = self.region
            event['exceptionId']= self.applicableRuleConfiguration['ExceptionId']
            event['exceptionName']= self.applicableRuleConfiguration['ExceptionName']
            event['alertEnabled']= alertsEnabled
            event['remediationEnabled']= remediationEnabled

            locationDetails = utils.getLocationData(self.region)
            event['Latitude'] = locationDetails['latitude']
            event['Longitude'] = locationDetails['longitude']
            event['regionCountry'] = locationDetails['region']

            # Get Event time
            if 'eventTime' in self.eventLog:
                event['timestamp'] = str(self.eventLog['eventTime'])
            else:
                event['timestamp'] = str(datetime.utcnow())

            # Get account name
            try:
                client = self.client
                if 'oss' in self.ruleName:
                    client = utils.getClient(self.context, self.accountId, self.region)

                alias = (json.loads(client.do_action_with_exception(GetAccountAliasRequest())))['AccountAlias']
            except:
                alias = 'NO ALIAS FOUND'

            event['accountName'] = alias

            event['detail'] = {
                'eventLog': self.eventLog,
                'customFields': self.getEventCustomPayload()
            }


            client = LogClient(config.LOG_STORE_REGION, self.context.credentials.accessKeyId, self.context.credentials.accessKeySecret, self.context.credentials.securityToken)
            item = LogItem()
            item.set_contents([("remediation_logs", json.dumps(event))])
            req = PutLogsRequest(config.REMEDIATION_LOGS['projectName'], config.REMEDIATION_LOGS['logStoreName'], event['alertType'], self.ruleName, [item], None, True, None)
            res = client.put_logs(req)
            logUtils.logInfo(MODULE_NAME,"############# REMEDIATION LOG SENT TO LOGSTORE #############")

        except Exception as e:
            logUtils.logError(MODULE_NAME, e)


class EventHandlerRAM(CsaoEventHandlerAlibaba):

    def __init__(self, ruleName, accountId, region, resource, eventLog, additionalInfo, context, client = None, violatorId = None):
        service = 'RAM'
        super().__init__(ruleName, accountId, region, violatorId, service, resource, eventLog, additionalInfo, context, client)

class EventHandlerActionTrail(CsaoEventHandlerAlibaba):

    def __init__(self, ruleName, accountId, region, resource, eventLog, additionalInfo, violatorId, context, client = None):
        service = 'Action Trail'
        super().__init__(ruleName, accountId, region, violatorId, service, resource, eventLog, additionalInfo, context, client)


class EventHandlerECS(CsaoEventHandlerAlibaba):

    def __init__(self, ruleName, accountId, region, resource, eventLog, additionalInfo, violatorId , context, client = None):
        service = 'ECS'
        super().__init__(ruleName, accountId, region, violatorId, service, resource, eventLog, additionalInfo, context, client)

    def getTags(self):
        from aliyunsdkecs.request.v20140526.DescribeTagsRequest import DescribeTagsRequest
        #Fetch ECS Instance Tags
        try:
            logUtils.logInfo(MODULE_NAME, "Getting tags...")
            tagsRequest = DescribeTagsRequest()
            tagsRequest.set_accept_format('json')
            tagsRequest.set_ResourceId(self.resource)
            tagsRequest.set_PageSize(100)

            pageNumber = 1
            tagList = []
            while(True):
                tagsRequest.set_PageNumber(pageNumber)
                tagsResponse = json.loads(self.client.do_action_with_exception(tagsRequest))
                tagList.extend(tagsResponse['Tags']['Tag'])
                pageNumber += 1
                if int(tagsResponse['TotalCount']) < int(tagsResponse['PageSize']):
                    break

            logUtils.logInfo(MODULE_NAME, f'Tags: {tagList}')
            return tagList

        except Exception as e:
            logUtils.logInfo(MODULE_NAME, 'Error while getting tags...')
            logUtils.logError(MODULE_NAME, e)

class EventHandlerOSS(CsaoEventHandlerAlibaba):

    def __init__(self, ruleName, accountId, region, resource, eventLog, additionalInfo, violatorId , context, client = None):
        service = 'Oss'
        super().__init__(ruleName, accountId, region, violatorId, service, resource, eventLog, additionalInfo, context, client)

    def getClient(self):
        import oss2
        from aliyunsdkcore.auth.credentials import StsTokenCredential
        from aliyunsdkcore.client import AcsClient
        from aliyunsdksts.request.v20150401.AssumeRoleRequest import AssumeRoleRequest

        try:

            roleName = config.ASSUME_ROLE

            creds = StsTokenCredential(self.context.credentials.accessKeyId, self.context.credentials.accessKeySecret, self.context.credentials.securityToken)
            client = AcsClient(credential = creds, region_id = self.context.region)

            request = AssumeRoleRequest()
            request.set_accept_format('json')
            request.set_RoleArn(f"acs:ram::{self.accountId}:role/{roleName}")
            request.set_RoleSessionName("csao")

            response = client.do_action_with_exception(request)

            response = json.loads(response.decode('utf-8'))

            accessKeyId = response['Credentials']['AccessKeyId']
            accessKeySecret = response['Credentials']['AccessKeySecret']
            securityToken = response['Credentials']['SecurityToken']
            auth = oss2.StsAuth(accessKeyId, accessKeySecret, securityToken)
            endpoint = f'oss-{self.region}.aliyuncs.com'
            bucket = oss2.Bucket(auth, endpoint, self.resource)
            return bucket
        except Exception as e:
            logUtils.logInfo(MODULE_NAME, 'Error fetching oss client...')
            logUtils.logError(MODULE_NAME, e)

    def getTags(self):
        '''Fetch OSS bucket tags'''

        try:
            logUtils.logInfo(MODULE_NAME, "Getting tags...")
            bucketTags = self.client.get_bucket_tagging()
            dictRule = bucketTags.tag_set.tagging_rule
            listRule = []
            for key in dictRule:
                listRule.append({
                "TagKey": key,
                "TagValue": dictRule[key]})
            return listRule

        except Exception as e:
            logUtils.logInfo(MODULE_NAME, 'Error while getting tags...')
            logUtils.logError(MODULE_NAME, e)


class EventHandlerVPC(CsaoEventHandlerAlibaba):

    def __init__(self, ruleName, accountId, region, resource, eventLog, additionalInfo, violatorId , service, context, client = None):
        super().__init__(ruleName, accountId, region, violatorId, service, resource, eventLog, additionalInfo, context, client)

    def getTags(self):
        from VPC_SDK.ListTagResourcesRequest import ListTagResourcesRequest

        #Fetch VPC Tags
        try:
            logUtils.logInfo(MODULE_NAME, "Getting tags...")
            request = ListTagResourcesRequest()
            request.set_accept_format('json')

            request.set_ResourceType(self.service)
            request.set_ResourceIds([self.resource])
            tagList = []
            while(True):
                response = json.loads(self.client.do_action_with_exception(request))
                for tag in response['TagResources']['TagResource']:
                    tagList.append({
                    "TagKey": tag['TagKey'],
                    "TagValue": tag['TagValue']
                    })

                if response['NextToken']:
                    request.set_NextToken(response['NextToken'])
                else:
                    break

            print(tagList)
            return tagList

        except Exception as e:
            logUtils.logInfo(MODULE_NAME, 'Error while getting tags...')
            logUtils.logError(MODULE_NAME, e)



class EventHandlerSLB(CsaoEventHandlerAlibaba):

    def __init__(self, ruleName, accountId, region, resource, eventLog, additionalInfo, violatorId , context, client = None):
        service = 'SLB'
        super().__init__(ruleName, accountId, region, violatorId, service, resource, eventLog, additionalInfo, context, client)

    def getTags(self):
        from SLB_SDK.DescribeTagsRequest import DescribeTagsRequest
        #from aliyunsdkslb.request.v20140515.DescribeTagsRequest import DescribeTagsRequest
        #Fetch SLB Instance Tags
        try:
            pageNumber = 1
            request = DescribeTagsRequest()
            request.set_accept_format('json')

            request.set_LoadBalancerId(self.resource)
            request.set_PageSize(100)
            tagList = []
            while(True):
                request.set_PageNumber(pageNumber)
                response = json.loads(self.client.do_action_with_exception(request))
                for tag in response['TagSets']['TagSet']:
                    tagList.append({
                        "TagKey": tag['TagKey'],
                        "TagValue": tag['TagValue']
                    })
                pageNumber += 1
                if int(response['TotalCount']) < int(response['PageSize']):
                    break

            print(tagList)
            return tagList

        except Exception as e:
            logUtils.logInfo(MODULE_NAME, 'Error while getting tags...')
            logUtils.logError(MODULE_NAME, e)
